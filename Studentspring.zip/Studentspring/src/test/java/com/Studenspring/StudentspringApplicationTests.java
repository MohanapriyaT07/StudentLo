package com.Studenspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentspringApplicationTests {

	@Test
	void contextLoads() {
	}

}
